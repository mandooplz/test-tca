//
//  ContentView.swift
//  PdfTest
//
//  Created by 송영민 on 11/14/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        RootTabView()
    }
}

#Preview {
    ContentView()
}
